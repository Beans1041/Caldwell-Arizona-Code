#include <iostream>
#include <fstream>

#include "TexasStruct.h"
#include "NewMexicoStruct.h"
#include "ArizonaStruct.h"

using namespace std;

int main()
{
    ofstream outFile;
     
    outFile.open("CaldwellToArizona.dat");

    const int GallonsToFillTruck = 20 ; 
    const float TotalDistance = 1083.5 ;
    const float AverageGastank = 350;

    double FlightTicket;
    double AmountOfTimesToFillTruck = TotalDistance / AverageGastank ;

    string TownOne = "Caldwell";
    string TownTwo = "Phoenix" ; 

     cout << "Enter the cost of the flight ticket : ";
     cin >> FlightTicket;
     cout << endl;
     
     cout << "Open CaldwellToArizona.dat" << endl;

     /**************OutPut The Basic Information Needed **************/
     outFile << "From Caldwell to Phoenix it is : " << TotalDistance 
          << endl << "You will need to fill up this many times : " << AmountOfTimesToFillTruck 
          << endl << endl;

    /**************Texas OutPut Data from header File *********/
      struct TexasData TexasInfo;
          
          outFile << "Amount of Times Needed to Refill in Texas " << TexasInfo.TimeTruckFilledWithGasTexas 
          << endl << "Cost in Texas : " << TexasInfo.GasCostTexas << endl << endl ;

     /************** New Mexico Output File ***************/
     struct NewMexicoData NewMexicoInfo ;
          
          outFile << "Amount of Times Needed To Refill in New Mexico: " << NewMexicoInfo.TimeTruckFilledWithGasNewMexico 
          << endl << "Cost in New Mexico : " << NewMexicoInfo.GasCostNewMexico << endl << endl;

     /************** Arizona Output File ***************/
      struct ArizonaData ArizonaInfo ;

          outFile << "Amount of Times Needed To Refill in Arizona: " << ArizonaInfo.TimeTruckFilledWithGasArizona 
          << endl << "Cost in New Mexico : " << ArizonaInfo.GasCostArizona << endl << endl;
          
    /***** This is the sum cost of everything for the trip *****/
    double TotalSumCost = ArizonaInfo.GasCostArizona + TexasInfo.GasCostTexas + NewMexicoInfo.GasCostNewMexico ;

     /*********Comparing the plane ticket and the total sum cost and stating what is better to do**********/
          if (FlightTicket < TotalSumCost)
          {
               outFile << "Your better of going in plane." << endl;
          }
          else 
          {
               outFile << "Your better off going by car." << endl; 
          }

    outFile << endl;
    outFile << "The following is what you are going to have to pay for the trip in car : " << TotalSumCost  << endl;
    outFile << "The following for on plane:  " << FlightTicket ;

    outFile.close();

    return 0 ;  

}