#include <iostream>

    const int GallonsToFillTruck = 20 ; 
  
    const float TotalDistance = 1083.5 ;

    const float AverageGastank = 350;
