#include <iostream>

struct TexasData
{
    const int GallonsToFillTruck = 20 ; 
  
    const float TotalDistance = 1083.5 ;

    const float AverageGastank = 350;

    float TexasGasPrice = 3.5 ;
    float DistanceInTexas = 654;
    float  GasCostTexas = TexasGasPrice * (2*(GallonsToFillTruck)) ;
    float TimeTruckFilledWithGasTexas = DistanceInTexas / AverageGastank ;

};
