#include <iostream>


struct ArizonaData

{
    const int GallonsToFillTruck = 20 ; 
  
    const float TotalDistance = 1083.5 ;

    const float AverageGastank = 350;

    float ArizonaGasPrice = 4.6 ;
    float DistanceInArizona = 270 ; 
    float GasCostArizona = ArizonaGasPrice * GallonsToFillTruck ;
    float TimeTruckFilledWithGasArizona = DistanceInArizona / AverageGastank ;

};