#include <iostream>

struct TexasData
{
    
    float TexasGasPrice = 3.5 ;
    float DisanceInTexas = 654;
    float  GasCostTexas = TexasGasPrice * (2*(GallonsToFillTruck)) ;
    float TimeTruckFilledWithGasTexas = DistanceInTexas / AverageGastank ;

};
