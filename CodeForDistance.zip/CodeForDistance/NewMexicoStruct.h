#include <iostream>

struct NewMexicoData
{
    const int GallonsToFillTruck = 20 ; 
  
    const float TotalDistance = 1083.5 ;

    const float AverageGastank = 350;

    float NewMexicoGasPrice = 3.9;
    float DistanceInNewMexico = 162 ;
    float GasCostNewMexico = NewMexicoGasPrice * GallonsToFillTruck ;
    float TimeTruckFilledWithGasNewMexico = DistanceInNewMexico / AverageGastank ;

};